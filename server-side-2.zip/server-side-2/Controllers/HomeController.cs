﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using server_side_2.Models;

namespace server_side_2.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }
    public IActionResult About()
    {
        return View();
    }
    public IActionResult Call()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    public IActionResult Store(Products product)
        {
            List<Products> products = new List<Products>();
            Products product01 = new Products();
            product01.Id = 1;
            product01.Name = "سامسونگ گلگسی";
            product01.Specification = "مدل s23";
            product01.Description = "";
            product01.Category = "تلفن همراه";
            product01.Price = 28500000;
            product01.Inventory = true;
            products.Add(product01);
            Products product02 = new Products();
            product02.Id = 2;
            product02.Name = "سامسونگ گلگسی";
            product02.Specification = "مدل s23 Plus";
            product02.Description = "";
            product02.Category = "تلفن همراه";
            product02.Price = 31000000;
            product02.Inventory = true;
            products.Add(product02);
            Products product03 = new Products();
            product03.Id = 3;
            product03.Name = "سامسونگ گلگسی";
            product03.Specification = "مدل s23 Ultra";
            product03.Description = "";
            product03.Category = "تلفن همراه";
            product03.Price = 40200000;
            product03.Inventory = true;
            products.Add(product03);
            Products product04 = new Products();
            product04.Id = 4;
            product04.Name = "اپل آیفون";
            product04.Specification = "15";
            product04.Description = "";
            product04.Category = "تلفن همراه";
            product04.Price = 45000000;
            product04.Inventory = true;
            products.Add(product04);
            Products product05 = new Products();
            product05.Id = 5;
            product05.Name = "اپل آیفون";
            product05.Specification = "15 Pro";
            product05.Description = "";
            product05.Category = "تلفن همراه";
            product05.Price = 48700000;
            product05.Inventory = true;
            products.Add(product05);
            Products product06 = new Products();
            product06.Id = 6;
            product06.Name = "اپل آیفون";
            product06.Specification = "15 Pro Max";
            product06.Description = "";
            product06.Category = "تلفن همراه";
            product06.Price = 55000000;
            product06.Inventory = true;
            products.Add(product06);
            var p = products.Where(x=>x.Inventory).ToList();
            var sum= products.Sum(x=>x.Price);
            ViewBag.Sum = sum;
            return View(p);
        }


    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
